import matplotlib.pyplot as plt
import numpy as np

list1=[]
list2=[]
list3=[]

for x in np.arange(-2, 6,0.1):
    f1=-(x**2) + 4*x + 5
    list1.append(f1)
    f2=-(2*x) + 4
    list2.append(f2)
    f3=-2
    list3.append(f3)

x=np.arange(-2, 6,0.1)
plt.scatter(x,list1,s=2,c='r')
plt.scatter(x,list2,s=2,c='g')
plt.scatter(x,list3,s=2,c='b')
plt.xlabel('x')
plt.ylabel('y')
plt.title('f(x)')

plt.show()