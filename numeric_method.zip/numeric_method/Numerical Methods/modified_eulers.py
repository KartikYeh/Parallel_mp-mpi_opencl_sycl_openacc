h=0
x=[0]

for i in range(1,2):
    x.append(round((h+0.2),2))
    h=h+0.2
    
print(x)

y=1
for n in range(0,len(x)-1):
    y=y+0.2*(y-(x[n]**2))
    print("value of y(0.2) by Eulers Method is: ",y)

y=y-(0.2)**2
    
print("f(x1,y1): ",y)

y1=1.16
y=1
h=0.2

for i in range(0,2):
    y1=y+(h/2)*((y)+(y1-x[i]**2))
    y1=y1-x[i]**2
    
y2=1+(h/2)*(1+y1)

print("Value of y(0.2) by modified Eulers Method is : ",y2)