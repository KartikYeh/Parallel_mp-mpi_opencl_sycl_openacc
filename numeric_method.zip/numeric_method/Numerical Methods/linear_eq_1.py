import matplotlib.pyplot as plt
import numpy as np

def linear_equation(x):
    return 3 - 2 * x

x = np.linspace(-10, 10, 100)

y = linear_equation(x)

plt.plot(x, y)

plt.xlabel('x')
plt.ylabel('y')
plt.title('y+2x=3')

plt.show()