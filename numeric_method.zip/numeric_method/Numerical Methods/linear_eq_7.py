import matplotlib.pyplot as plt
import numpy as np


x = np.linspace(-10, 10, 100)
y=[]
for i in range(0,len(x)):
    y.append(6)

plt.plot(x, y)

plt.xlabel('x')
plt.ylabel('y')
plt.title('f(x)=6')

plt.show()