import numpy as np

N=100000

x=np.random.uniform(-1,1,N)
y=np.random.uniform(-1,1,N)

n=0

for i in range(0,len(x)):
    if (x[i]**2+y[i]**2)<=1:
        n=n+1

pi=4*(n/N)
print(pi)