import math
# Truncation
print(math.trunc(-10.90))

# Round-off
print(round(1.5))
print(round(1.2))
print(round(1.7))
