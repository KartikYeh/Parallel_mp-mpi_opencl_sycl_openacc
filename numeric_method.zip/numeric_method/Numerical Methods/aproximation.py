# Find approximate value of the cube root 27
guess = 0.0
cube = 27
increment =0.1
epsilon = 0.1

# Finding the approximate value
while abs(guess**3 - cube) >=epsilon:
    guess+=increment

# Cheaking the approximate value
if abs(guess**3 -cube) >=epsilon:
     print("failed on the cube root of",cube)

else:
    print(guess,"is close to the cube root of",cube)


