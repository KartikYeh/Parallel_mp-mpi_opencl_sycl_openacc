import numpy as np
N=100000

x= np.random.normal(5,1,N)
y= np.random.normal(10,1,N)
z= np.random.normal(15,1,N)

total=0

for i in range(0,len(x)):
    if((x[i]+y[i]+z[i])>=34):
        total=total+1

ans=(total*100)/N

print(ans,"%")