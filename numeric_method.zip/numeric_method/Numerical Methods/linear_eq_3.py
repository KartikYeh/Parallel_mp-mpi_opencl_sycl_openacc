import matplotlib.pyplot as plt
import numpy as np

def linear_equation(x):
    return (6-2*(x)/3)

x = np.linspace(-10, 10, 100)

y = linear_equation(x)

plt.plot(x, y)

plt.xlabel('x')
plt.ylabel('y')
plt.title('2x+3y-6=0 ')

plt.show()