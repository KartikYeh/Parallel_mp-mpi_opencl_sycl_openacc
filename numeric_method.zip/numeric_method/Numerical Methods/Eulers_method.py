h=0
x=[0]

for i in range(1,7):
    x.append(round((h+0.02),2))
    h=h+0.02
    
print(x)


y=1
for n in range(0,len(x)-1):
    y1=y+0.02*((x[n]**3)+y)
    y=y1
    
print("value of y(0.12)is: ",y)