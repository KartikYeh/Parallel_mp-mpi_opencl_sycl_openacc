import matplotlib.pyplot as plt
import numpy as np

def f(x):
    return 6 * (x - 2) + 3

x = np.linspace(-10, 10, 100)

y = f(x)

plt.plot(x, y)

plt.xlabel('x')
plt.ylabel('y')
plt.title('y - 3 = 6(x - 2)')

plt.show()