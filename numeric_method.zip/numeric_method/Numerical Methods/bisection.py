from math import sin
from math import cos

a=float(input("Enter value of a\n"))
b=float(input("Enter value of b\n"))
def f(x):
    z=(sin(5*x)+cos(2*x))
    return z

while True:
    if(f(a)*f(b)<0):
        x=(a+b)/2
        if(round(f(x),3)==0):
            print("Root Found",round(x,3))
            break
        elif((f(a)*f(x))<0):
            b=x
            
        else:
            a=x
            
    else:
        print("Root Not Exist")
        break