import matplotlib.pyplot as plt
import numpy as np

def linear_equation(x):
    return (1-x/2)*3

x = np.linspace(-10, 10, 100)

y = linear_equation(x)

plt.plot(x, y)

plt.xlabel('x')
plt.ylabel('y')
plt.title('x/2+y/3=1')

plt.show()