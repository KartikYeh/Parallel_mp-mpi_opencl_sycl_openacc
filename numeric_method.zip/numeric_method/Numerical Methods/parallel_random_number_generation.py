from numpy.random import SeedSequence,default_rng
ss=SeedSequence(12345)
#spawn off 10 child Seedsequences to pass to child processes
child_seeds=ss.spawn(10)
streams=[default_rng(s) for s in child_seeds]#threads
grandchildren=child_seeds[0].spawn(4)
grand_streams=[default_rng(s) for s in grandchildren]
print(grandchildren[0].pool)