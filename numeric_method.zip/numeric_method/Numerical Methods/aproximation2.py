counter = 0
cube = 27
increment = 0.1
epsilon = 0.1
guess=0.0

while counter < 30 and abs(guess**3 - cube) >= epsilon:
   guess += increment
   counter += 1

if abs(guess**3 - cube) >= epsilon:
   print("failed on the cube root of", cube)

else:
   print(guess, "is close to the cube root of", cube)