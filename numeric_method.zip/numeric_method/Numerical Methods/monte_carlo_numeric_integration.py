import numpy as np
from scipy.integrate import quad

a=-2
b=5

s=np.random.uniform(a,b,15000)

sum=0
def f(x):
    return abs((x**3+(6*(x)**2)-x+17))
    
for i in s:
    sum+=(((b-a)*f(i)))
result=((1/len(s))*sum)
print(result)

result1, err1 = quad(f, a,b)
print(result1)