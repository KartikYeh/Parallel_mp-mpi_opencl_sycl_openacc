import pandas as pd

data = {'x': [1.27 , 2.25 , 2.5 , 3.6],
        'y': [2.3 , 2.95 , 3.5 , 5.1]}
data=pd.DataFrame.from_dict(data)
x = 0
y = 4.5
n = 4

for i in range(0,n):
    xi =  data.x[i]
    for j in range(0,n):
        if(i!=j):
            xi=(xi*(y - data.y[j]))/(data.y[i] - data.y[j])
    x=xi+x
print(x)