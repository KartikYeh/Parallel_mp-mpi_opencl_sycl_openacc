import matplotlib.pyplot as plt

guess = 0.0
cube = 27
increment =0.1
epsilon = 0.1

g = [guess]
while abs(guess**3 - cube) >=epsilon:
   guess+=increment
   g.append(guess)

if abs(guess**3 -cube) >=epsilon:
    print("failed on the cube root of",cube)

else:
   print(guess,"is close to the cube root of",cube)

plt.plot(g)
plt.xlabel("Guess")
plt.show()

plt.plot([abs(guess**3 - cube) for guess in g])
plt.xlabel("error")
plt.show()


plt.plot(g)
plt.plot([abs(guess**3 - cube) for guess in g])
plt.xlabel("Guess")
plt.ylabel("error")
plt.title("Guess vs error")
plt.show()
