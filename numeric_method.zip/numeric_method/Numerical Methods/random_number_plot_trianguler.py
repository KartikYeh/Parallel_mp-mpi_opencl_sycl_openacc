import numpy as np
import matplotlib.pyplot as plt
# import numpy.random as rnd
s=np.random.triangular(-3,0,8,100000)
plt.hist(s, bins=25, density=False, alpha=0.6)
plt.show()