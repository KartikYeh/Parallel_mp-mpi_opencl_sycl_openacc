from math  import sin,cos


# a=0.1
# b=0.9
a= 0.1
b= 0.9

def f(x):
    z= sin(5*x) + cos(2*x)
    return z

while True:
    if ( f(a) * f(b) < 0 ):
        xi=(a+b)/2
        
        if (round(f(xi),3) == 0):
            print("The root of equation is ",round( xi , 3))
            break
        elif (f(xi) * f(a) <0):
            b =xi
        elif( f(xi) * f(b)<0 ):
            a=xi
    else:
        print("Root does not exits for the equation")
        break
    
    #output for a =0.1 b=0.9
    #The root of equation is  0.673
    
    
    #output for a =0.1 b=0.9
    #Root does not exits for the equation
    
    #output for a =0. b=0.9
    #Root does not exits for the equation
    
    #output for a = -0.3 b= -0.2
    #The root of equation is  -0.224
    
    #output for a = 0.5 b= 0.6
    #The root of equation is  -0.523