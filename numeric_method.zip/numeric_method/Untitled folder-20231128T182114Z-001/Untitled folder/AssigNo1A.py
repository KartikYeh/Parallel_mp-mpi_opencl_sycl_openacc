#  1). Write a python program to calculate approximate values of cube root of 27. 
# Avoid infinite looping using if-break statement

guess = 0.0
cube = 27
increment = 0.1
epsilon = 0.1 #Error Tolerence
	
	
for i in range (30):
    if abs(guess**3 -cube) >= epsilon:
        guess+=increment
        print("The cube ",cube)
    else:
        break
    
if abs(guess**3 -cube) >= epsilon:
	print ("Faild on the cube root of ",cube)
else:
	print(guess, "is close to the cube root of",cube)
 
 ## output
 
#  hpcsap-DIT400TR-55L% /bin/python3 "/home/hpcsap/CV/Python/Machine Lerning/Assignment/AssigNo1A.py"
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# 3.0000000000000013 is close to the cube root of 27