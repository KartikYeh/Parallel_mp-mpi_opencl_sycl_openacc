# 1). Write a python program to calculate approximate values of cube root of 27. 
# Avoid infinite looping using for Loop on a guess value
import numpy as np
guess = 0.0
cube = 27
increment = 0.1
epsilon = 0.1 #Error Tolerence
	
	
for guess in np.arange(0.1,4.0,0.1):
    if abs(guess**3 -cube) >= epsilon:
        print("The cube ",cube)
    else:
        break
    
if abs(guess**3 -cube) >= epsilon:
	print ("Faild on the cube root of ",cube)
else:
	print(guess, "is close to the cube root of",cube)
 
                       #OUTPUT
                       
# hpcsap-DIT400TR-55L% /bin/python3 "/home/hpcsap/CV/Python/Machine Lerning/Assignment/AssigNo1C.py"
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# The cube  27
# 3.0000000000000004 is close to the cube root of 27