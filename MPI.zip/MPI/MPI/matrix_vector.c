#include <stdio.h>
#include <mpi.h>

#define ROWS 3
#define COLS 3

void printMatrix(int matrix[][COLS]) {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

void matrixVectorAddition(int *vector, int matrix[][COLS], int *result, int rowStart, int rowCount) {
    for (int i = rowStart; i < rowStart + rowCount; i++) {
        for (int j = 0; j < COLS; j++) {
            result[i] += vector[j] + matrix[i][j];
        }
    }
}

int main(int argc, char *argv[]) {
    int numTasks, rank;
    int matrix[ROWS][COLS] = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
    int vector[COLS] = {1, 2, 3};
    int result[ROWS] = {0};

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &numTasks);

    int chunkSize = ROWS / numTasks;
    int rowStart = rank * chunkSize;

    if (rank == numTasks - 1) {
        chunkSize += ROWS % numTasks;
    }

    int rowEnd = rowStart + chunkSize;

    matrixVectorAddition(vector, matrix, result, rowStart, chunkSize);

    if (rank != 0) {
        MPI_Send(result + rowStart, chunkSize, MPI_INT, 0, rank, MPI_COMM_WORLD);
    } else {
        for (int i = 1; i < numTasks; i++) {
            MPI_Recv(result + i * chunkSize, chunkSize, MPI_INT, i, i, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        }
    }

    if (rank == 0) {
        printf("Matrix:\n");
        printMatrix(matrix);
        printf("\nVector: %d %d %d", vector[0], vector[1], vector[2]);

        printf("\nResult:\n");
        for (int i = 0; i < ROWS; i++) {
            printf("%d", result[i]);
        }
    }
  
    MPI_Finalize();
    return 0;
}
