#include "stdio.h"
#include "mpi.h"

int main(int argc, char **argv)
{

        int myid,size,i;
        //initialize MPI enviroment
        MPI_Init(&argc,&argv);

        //get total number of process
        MPI_Comm_size(MPI_COMM_WORLD,&size);

        //get my unique id among all processes
        MPI_Comm_rank(MPI_COMM_WORLD,&myid);

        int start ,end;
        int N=10;
        start=myid*(N/size);
        end=start+(N/size);
        if(myid==(size-1)){
                end=N;
        }

        for(i=start;i<end;i++)
        {
        printf("\n Process number %d : processing %d.\n",myid, i);
        }
        //End of MPI environment
        MPI_Finalize();
        }
