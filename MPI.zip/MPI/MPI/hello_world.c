#include "stdio.h"
#include "mpi.h"

int main(int argc, char **argv)
{
	int myid,size;
	//initialize MPI enviroment
	MPI_Init(&argc,&argv);
	
	//get total number of process
	MPI_Comm_size(MPI_COMM_WORLD,&size);
	
	//get my unique id among all processes
	MPI_Comm_rank(MPI_COMM_WORLD,&myid);
	
	printf("Hello World from %d out of %d.\n",myid, size);
	//End of MPI environment
	MPI_Finalize();
}
	
