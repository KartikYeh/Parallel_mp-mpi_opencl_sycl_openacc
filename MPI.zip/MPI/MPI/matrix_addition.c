#include<stdio.h>
#include<mpi.h>

void Accept(int matrix[3][3]) {
    printf("Enter the elements of the matrix:\n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            scanf("%d",&matrix[i][j]);
        }
    }
}
void Display(int matrix[3][3]) {
    printf("Matrix:\n");
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}



void MatrixAddition(int matrix1[3][3], int matrix2[3][3], int result[3][3]) {
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            result[i][j] = matrix1[i][j] + matrix2[i][j];
        }
    }
}

int main(int argc, char** argv) {

    int N=3;
    int matrix1[N][N], matrix2[N][N], transpose[N][N], result[N][N],matrixn1[N][N], matrixn2[N][N],resultMatrix[N][N];
    int rank, size;
    
    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);
if(rank==0){
    
    Accept(matrix1);
    Accept(matrix2);

    
    Display(matrix1);
    printf("Matrix2 is \n");
    Display(matrix2);
}
    MPI_Scatter(matrix1, N*N/size, MPI_INT, matrixn1, N*N/size, MPI_INT, 0, MPI_COMM_WORLD);
    MPI_Scatter(matrix2, N*N/size, MPI_INT, matrixn2, N*N/size, MPI_INT, 0, MPI_COMM_WORLD);
    
    MatrixAddition(matrixn1, matrixn2, result); 
    MPI_Gather(result, N*N/size, MPI_INT, resultMatrix, N*N/size, MPI_INT, 0, MPI_COMM_WORLD);

        
    if(rank==0){
    printf("Resultant Matrix after addition:\n");
    Display(resultMatrix);
    }
    
    MPI_Finalize();
    return 0;
    
}
